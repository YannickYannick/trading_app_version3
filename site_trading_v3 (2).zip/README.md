# trading_app_version3
Application de trading aidé par l'IA
