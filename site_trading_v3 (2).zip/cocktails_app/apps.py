from django.apps import AppConfig


class CocktailsAppConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "cocktails_app"
    verbose_name = "Cocktails"