from django.apps import AppConfig


class BachataAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'bachata_app'
    verbose_name = 'Bachata App' 